angular.module('CadastroApp',
    [
    'inputBootstrap'
    ]
);